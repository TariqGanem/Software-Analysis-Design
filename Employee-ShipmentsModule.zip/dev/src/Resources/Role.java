package Resources;

public enum Role {
    StoreManager,
    HRManager,
    Cashier,
    StoreKeeper,
    StoreManagerAssistant,
    Stocker,
    SecurityMan,
    Driver,
    ShiftManager,
    ShipmentsManager
}
