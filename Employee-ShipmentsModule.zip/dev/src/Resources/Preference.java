package Resources;

public enum Preference {
    WANT,
    CAN,
    CANT
}
